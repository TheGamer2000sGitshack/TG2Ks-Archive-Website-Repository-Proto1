# TG000's Fast Shack Selector
# By TheGamer2000, Program Build #7.1, 6/7/24
# Trinket Python B2 Build

#Initial boot phase
print ("TG2000's Fast Shack Selector")
print ("A Program by TheGamer2000, ©2024")
print (" ")
print ("NOTE: This is a MOCK meal selection program. There is NO food delivery. If you're looking for food, go to McDonalds or something.")
print (" ")
print (" ")
print ("-𝐓𝐆𝟐𝟎𝟎𝟎'𝐬 𝐅𝐀𝐒𝐓 𝐒𝐇𝐀𝐂𝐊-")
print (" ")
print ("Welcome to TG2000's Fast Shack!")
name = input ("Before we take your order, what is your name?")
print (" ")
if name == ("devnotes"):
 print("Hello, developer. Here's some notes for you:")
 print("This program took 2 weeks to program. There's a total of 1,568 lines in this program.")
 print("Those freshman will explode upon seeing this code lol")
 print("I'd suggest using Python with CMD on Windows!")
 print("There's 2 secrets for you at the end. Find them...")
 print("If you aren't a developer, what are you doing here??? GET OUT.")
 print(" ")
 stopdev = input ("Press ENTER key to continue to program.")
 print(" ")
print ("Thank you, " + (name) + ".")
print (" ")
print ("Begin typing your request below when the cursor is visible.")
print (" ")


#Sandwich Phase
print ("What sandwich from this selection would you like to order?")
print (" ")

print ("You have 3 options: Chicken, Beef, or Tofu.")
print ("Chicken costs $5.25, Beef costs $6.25, and Tofu costs $5.75.")
print (" ")
sandwich = input ("Please input your order. (If you do not want a sandwich, leave the cursor blank.)")
print (" ")

#Subtract Order Early
benefit = 0
tally = 0

#Sandwich price phase
chicken = 5.25
beef = 6.25
tofu = 5.75
blank = 0
total = 0

#Chicken
if sandwich == "chicken":
 print ("You have selected the " + sandwich + " option.")
 print (" ")
 print ("The price for this sandwich is $" + str(chicken) + ".")
 total = chicken
 tally = int(benefit) + int(1)
 SWF = "Chicken"

if sandwich == "Chicken":
  print ("You have selected the " + sandwich + " option.")
  print (" ")
  print ("The price for this sandwich is $" + str(chicken) + ".")
  total = chicken
  tally = int(benefit) + int(1)
  SWF = "Chicken"
  
if sandwich == "CHICKEN":
  print ("You have selected the " + sandwich + " option.")
  print (" ")
  print ("The price for this sandwich is $" + str(chicken) + ".")
  print (" ")
  total = chicken
  tally = int(benefit) + int(1)
  SWF = "Chicken"


#Beef
if sandwich == "beef":
  print ("You have selected the " + sandwich + " option.")
  print (" ")
  print ("The price for this sandwich is $" + str(beef) + ".")
  print (" ")
  tally = int(benefit) + int(1)
  total = beef
  SWF = "Beef"


if sandwich == "Beef":
  print ("You have selected the " + sandwich + " option.")
  print (" ")
  print ("The price for this sandwich is $" + str(beef) + ".")
  tally = int(benefit) + int(1)
  SWF = "Beef"
  total = beef
  
if sandwich == "BEEF":
  print ("You have selected the " + sandwich + " option.")
  print (" ")
  print ("The price for this sandwich is $" + str(beef) + ".")
  print (" ")
  total = beef
  tally = int(benefit) + int(1)
  SWF = "Beef"


  
#Tofu
if sandwich == "tofu":
  print ("You have selected the " + sandwich + " option.")
  print (" ")
  print ("The price for this sandwich is $" + str(tofu) + ".")
  total = tofu
  tally = int(benefit) + int(1)
  SWF = "Tofu"

  
if sandwich == "Tofu":
  print ("You have selected the " + sandwich + " option.")
  print (" ")
  print ("The price for this sandwich is $" + str(tofu) + ".")
  tally = int(benefit) + int(1)
  total = tofu
  SWF = "Tofu"

  
if sandwich == "TOFU":
  print ("You have selected the " + sandwich + " option.")
  print (" ")
  print ("The price for this sandwich is $" + str(tofu) + ".")
  print (" ")
  total = tofu
  tally = int(benefit) + int(1)
  SWF = "Tofu"


#Nothing
if sandwich == "":
  print ("You did not select a sandwich.")
  SWF = "None"

if sandwich == "No":
  print ("You did not select a sandwich.")
  SWF = "None"

if sandwich == "NO":
  print ("You did not select a sandwich.")
  SWF = "None"

if sandwich == "no":
  print ("You did not select a sandwich.")
  SWF = "None"
  total = blank
  
#First Total Message
print (" ")
print ("At this time, your total order price is $" + str(total) + ".")
print (" ")

#Coke price phase
large = 2.25
medium = 1.75
small = 1.00
blank = 0

#Beverage Phase
print ("For your beverage, we have provided 𝐂𝐨𝐤𝐞 in three sizes.")
print (" ")
coke = input ("Would you like to take this offer? (If yes, we will provide a list of sizes for you to select. If no (Or left blank), we will move on to the next section.")
print (" ")

if coke == "No":
  print ("Your 𝐂𝐨𝐤𝐞 will not be included in your order.")
  print (" ")
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  CK = "None"
  
if coke == "NO":
  print ("Your 𝐂𝐨𝐤𝐞 will not be included in your order.")
  print (" ")
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  CK = "None"

  
if coke == "no":
  print ("Your 𝐂𝐨𝐤𝐞 will not be included in your order.")
  print (" ")
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  CK = "None"

  
if coke == "":
  print ("Your 𝐂𝐨𝐤𝐞 will not be included in your order.")
  print (" ")
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  CK = "None"

  
if coke == "Yes":
 print ("Which size from this selection would you like to order?")
 print (" ")

 print ("You have 3 options: Small, Medium, or Large.")
 print ("Small costs $1.00, Medium costs $1.75, and Large costs $2.25.")
 print (" ")
 size = input ("Please input your order. (If you've decided to change your mind, leave the cursor blank.)")
 print (" ")
 
 if size == "":
  print ("Looks like you've changed your mind.")
  print (" ")
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  CK = "None"

 
 if size == "small":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(small) + ".")
  print (" ")
  total = float(small) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Small"

  
 if size == "Small":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(small) + ".")
  print (" ")
  total = float(small) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Small"
  
 if size == "SMALL":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(small) + ".")
  print (" ")
  total = float(small) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Small"

 if size == "medium":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(medium) + ".")
  print (" ")
  total = float(medium) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Medium"

 if size == "Medium":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(medium) + ".")
  print (" ")
  total = float(medium) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Medium"
  
 if size == "MEDIUM":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(medium) + ".")
  print (" ")
  total = float(medium) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Medium"
  
 if size == "large":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(large) + ".")
  print (" ")
  total = float(large) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Large"

 if size == "Large":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(large) + ".")
  print (" ")
  total = float(large) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Large"

 if size == "LARGE":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(large) + ".")
  print (" ")
  total = float(large) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Large"
  
if coke == "yes":
 print ("Which size from this selection would you like to order?")
 print (" ")

 print ("You have 3 options: Small, Medium, or Large.")
 print ("Small costs $1.00, Medium costs $1.75, and Large costs $2.25.")
 print (" ")
 size = input ("Please input your order. (If you've decided to change your mind, leave the cursor blank.)")
 print (" ")
 
 if size == "small":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(small) + ".")
  print (" ")
  total = float(small) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Small"
  
 if size == "Small":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(small) + ".")
  print (" ")
  total = float(small) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Small"
  
 if size == "SMALL":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(small) + ".")
  print (" ")
  total = float(small) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Small"

 if size == "medium":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(medium) + ".")
  print (" ")
  total = float(medium) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Medium"

 if size == "Medium":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(medium) + ".")
  print (" ")
  total = float(medium) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Medium"
  
 if size == "MEDIUM":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(medium) + ".")
  print (" ")
  total = float(medium) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Medium"
  
 if size == "large":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(large) + ".")
  print (" ")
  total = float(large) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Large"

 if size == "Large":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(large) + ".")
  print (" ")
  total = float(large) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Large"

 if size == "LARGE":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(large) + ".")
  print (" ")
  total = float(large) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Large"
  
 if size == "":
  print ("Looks like you've changed your mind.")
  print (" ")
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  CK = "None"

  
if coke == "YES":
 print ("Which size from this selection would you like to order?")
 print (" ")

 print ("You have 3 options: Small, Medium, or Large.")
 print ("Small costs $1.00, Medium costs $1.75, and Large costs $2.25.")
 print (" ")
 size = input ("Please input your order. (If you've decided to change your mind, leave the cursor blank.)")
 print (" ")
 
 if size == "small":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(small) + ".")
  print (" ")
  total = float(small) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Small"
  
 if size == "Small":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(small) + ".")
  print (" ")
  total = float(small) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Small"
  
 if size == "SMALL":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(small) + ".")
  print (" ")
  total = float(small) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Small"

 if size == "medium":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(medium) + ".")
  print (" ")
  total = float(medium) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Medium"

 if size == "Medium":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(medium) + ".")
  print (" ")
  total = float(medium) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Medium"
  
 if size == "MEDIUM":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(medium) + ".")
  print (" ")
  total = float(medium) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Medium"
  
 if size == "large":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(large) + ".")
  print (" ")
  total = float(large) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Large"
  
 if size == "Large":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(large) + ".")
  print (" ")
  total = float(large) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Large"
  
 if size == "LARGE":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this 𝐂𝐨𝐤𝐞 is $" + str(large) + ".")
  print (" ")
  total = float(large) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  CK = "Large"


 if size == "":
  print ("Looks like you've changed your mind.")
  print (" ")
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  CK = "None"


#Fry Price Phase
flarge = 2.00
fmedium = 1.50
fsmall = 1.00
fblank = 0

#Fry Phase
print ("We have provided fries with your order in three sizes.")
print (" ")
fry = input ("Would you like to take this offer? (If yes, we will provide a list of sizes for you to select. If no (Or left blank), we will move on to the next section.")
print (" ")

if fry == "No":
  print ("Your fries will not be included in your order.")
  print (" ")
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  fr = "None"
  
if fry == "no":
  print ("Your fries will not be included in your order.")
  print (" ")
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  fr = "None"

if fry == "NO":
  print ("Your fries will not be included in your order.")
  print (" ")
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  fr = "None"

if fry == "":
  print ("Your fries will not be included in your order.")
  print (" ")
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  fr = "None"
  
if fry == "YES":
 print ("Which size from this selection would you like to order?")
 print (" ")

 print ("You have 3 options: Small, Medium, or Large.")
 print ("Small costs $1.00, Medium costs $1.50, and Large costs $2.00.")
 print (" ")
 fsize = input ("Please input your order. (If you've decided to change your mind, leave the cursor blank.)")
 print (" ")
 
 if fsize == "small":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(fsmall) + ".")
  print (" ")
  print ("This size is relatively small, are you sure you want this size?")
  slarge = input ("We suggest that you should order our large size fries. Would you like to take this offer? (If you would like to stick with your choice, type No or leave the cursor blank. Else, type Yes.)")
  print (" ")
  
  if slarge == "No":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"

  if slarge == "NO":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
    
  if slarge == "no":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
    
  if slarge == "Yes":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"
  
  if slarge == "yes":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"
    
  if slarge == "YES":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"

  
 if fsize == "Small":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(fsmall) + ".")
  print (" ")
  print ("This size is relatively small, are you sure you want this size?")
  slarge = input ("We suggest that you should order our large size fries. Would you like to take this offer? (If you would like to stick with your choice, type No or leave the cursor blank. Else, type Yes.)")
  print (" ")
  
  if slarge == "No":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
  
  if slarge == "NO":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
    
  if slarge == "no":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
    
  if slarge == "Yes":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"
 
  if slarge == "yes":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"
    
  if slarge == "YES":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"

  
 if fsize == "SMALL":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(fsmall) + ".")
  print (" ")
  print ("This size is relatively small, are you sure you want this size?")
  slarge = input ("We suggest that you should order our large size fries. Would you like to take this offer? (If you would like to stick with your choice, type No or leave the cursor blank. Else, type Yes.)")
  print (" ")
  
  if slarge == "No":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
  
  if slarge == "NO":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
    
  if slarge == "no":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
    
  if slarge == "Yes":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"
  
  if slarge == "yes":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"
    
  if slarge == "YES":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"


 if fsize == "medium":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(fmedium) + ".")
  print (" ")
  total = float(medium) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  fr = "Medium"

 if fsize == "Medium":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(fmedium) + ".")
  print (" ")
  total = float(medium) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  fr = "Medium"
  
 if fsize == "MEDIUM":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(fmedium) + ".")
  print (" ")
  total = float(medium) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  fr = "Medium"
  
 if fsize == "large":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(flarge) + ".")
  print (" ")
  total = float(large) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  fr = "Large"

 if fsize == "Large":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(flarge) + ".")
  print (" ")
  total = float(large) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  fr = "Large"

 if fsize == "LARGE":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(flarge) + ".")
  print (" ")
  total = float(large) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  fr = "Large"
  
if fry == "Yes":
 print ("Which size from this selection would you like to order?")
 print (" ")

 print ("You have 3 options: Small, Medium, or Large.")
 print ("Small costs $1.00, Medium costs $1.50, and Large costs $2.00.")
 print (" ")
 fsize = input ("Please input your order. (If you've decided to change your mind, leave the cursor blank.)")
 print (" ")
 
 if fsize == "small":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(fsmall) + ".")
  print (" ")
  print ("This size is relatively small, are you sure you want this size?")
  slarge = input ("We suggest that you should order our large size fries. Would you like to take this offer? (If you would like to stick with your choice, type No or leave the cursor blank. Else, type Yes.)")
  print (" ")
  
  if slarge == "No":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
  
  if slarge == "NO":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
    
  if slarge == "no":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
    
  if slarge == "Yes":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"
  
  if slarge == "yes":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"
    
  if slarge == "YES":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"

  
 if fsize == "Small":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(fsmall) + ".")
  print (" ")
  print ("This size is relatively small, are you sure you want this size?")
  slarge = input ("We suggest that you should order our large size fries. Would you like to take this offer? (If you would like to stick with your choice, type No or leave the cursor blank. Else, type Yes.)")
  print (" ")
  
  if slarge == "No":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
  
  if slarge == "NO":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
    
  if slarge == "no":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
    
  if slarge == "Yes":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"
  
  if slarge == "yes":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"
    
  if slarge == "YES":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"

  
 if fsize == "SMALL":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(fsmall) + ".")
  print (" ")
  print ("This size is relatively small, are you sure you want this size?")
  slarge = input ("We suggest that you should order our large size fries. Would you like to take this offer? (If you would like to stick with your choice, type No or leave the cursor blank. Else, type Yes.)")
  print (" ")
  
  if slarge == "No":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
  
  if slarge == "NO":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
    
  if slarge == "no":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
    
  if slarge == "Yes":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"
  
  if slarge == "yes":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"
    
  if slarge == "YES":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"


 if fsize == "medium":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(fmedium) + ".")
  print (" ")
  total = float(medium) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  fr = "Medium"

 if fsize == "Medium":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(fmedium) + ".")
  print (" ")
  total = float(medium) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  fr = "Medium"
  
 if fsize == "MEDIUM":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(fmedium) + ".")
  print (" ")
  total = float(medium) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  fr = "Medium"
  
 if fsize == "large":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(flarge) + ".")
  print (" ")
  total = float(large) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  fr = "Large"

 if fsize == "Large":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(flarge) + ".")
  print (" ")
  total = float(large) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  fr = "Large"

 if fsize == "LARGE":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(flarge) + ".")
  print (" ")
  total = float(large) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  fr = "Large"
  
if fry == "yes":
 print ("Which size from this selection would you like to order?")
 print (" ")

 print ("You have 3 options: Small, Medium, or Large.")
 print ("Small costs $1.00, Medium costs $1.50, and Large costs $2.00.")
 print (" ")
 fsize = input ("Please input your order. (If you've decided to change your mind, leave the cursor blank.)")
 print (" ")
 
 if fsize == "small":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(fsmall) + ".")
  print (" ")
  print ("This size is relatively small, are you sure you want this size?")
  slarge = input ("We suggest that you should order our large size fries. Would you like to take this offer? (If you would like to stick with your choice, type No or leave the cursor blank. Else, type Yes.)")
  print (" ")
  
  if slarge == "No":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
  
  if slarge == "NO":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
    
  if slarge == "no":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
    
  if slarge == "Yes":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"
  
  if slarge == "yes":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"
    
  if slarge == "YES":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"

  
 if fsize == "Small":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(fsmall) + ".")
  print (" ")
  print ("This size is relatively small, are you sure you want this size?")
  slarge = input ("We suggest that you should order our large size fries. Would you like to take this offer? (If you would like to stick with your choice, type No or leave the cursor blank. Else, type Yes.)")
  print (" ")
  
  if slarge == "No":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
  
  if slarge == "NO":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
    
  if slarge == "no":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
    
  if slarge == "Yes":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"
  
  if slarge == "yes":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"
    
  if slarge == "YES":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"

  
 if fsize == "SMALL":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(fsmall) + ".")
  print (" ")
  print ("This size is relatively small, are you sure you want this size?")
  slarge = input ("We suggest that you should order our large size fries. Would you like to take this offer? (If you would like to stick with your choice, type No or leave the cursor blank. Else, type Yes.)")
  print (" ")
  
  if slarge == "No":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
  
  if slarge == "NO":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
    
  if slarge == "no":
    total = float(fsmall) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Small"
    
  if slarge == "Yes":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"
  
  if slarge == "yes":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"
    
  if slarge == "YES":
    print ("You have chosen to take our offer.")
    print (" ")
    total = float(flarge) + float(total)
    print ("At this time, your total order price is $" + str(total) + ".")
    print (" ")
    tally = int(tally) + int(1)
    fr = "Large"


 if fsize == "medium":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(fmedium) + ".")
  print (" ")
  total = float(medium) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  fr = "Medium"

 if fsize == "Medium":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(fmedium) + ".")
  print (" ")
  total = float(medium) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  fr = "Medium"
  
 if fsize == "MEDIUM":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(fmedium) + ".")
  print (" ")
  total = float(medium) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  fr = "Medium"
  
 if fsize == "large":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(flarge) + ".")
  print (" ")
  total = float(large) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  fr = "Large"

 if fsize == "Large":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(flarge) + ".")
  print (" ")
  total = float(large) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  fr = "Large"

 if fsize == "LARGE":
  print ("You have selected the " + size + " option.")
  print (" ")
  print ("The price for this size of fry is $" + str(flarge) + ".")
  print (" ")
  total = float(large) + float(total)
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  tally = int(tally) + int(1)
  fr = "Large"
  
 if fsize == "":
  print ("Looks like you've changed your mind.")
  print (" ")
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  fr = "None"
  
#Ketchup Phase
print ("To add some savory flavor to your order, would you like to include a ketchup packet?")
ketchup = 0.25
print (" ")
ketchput = input ("If you would like to take this offer, type Yes. Else, type No or leave the cursor blank.")
print (" ")

if ketchput == "No":
 print ("Looks like you don't want any ketchup packets.")
 print (" ")
 print ("At this time, your total order price is $" + str(total) + ".")
 print (" ")
 kcp = "0"

if ketchput == "NO":
 print ("Looks like you don't want any ketchup packets.")
 print (" ")
 print ("At this time, your total order price is $" + str(total) + ".")
 print (" ")
 kcp = "0"
   
if ketchput == "no":
  print ("Looks like you don't want any ketchup packets.")
  print (" ")
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  kcp = "0"
  
if ketchput == "":
  print ("Looks like you don't want any ketchup packets.")
  print (" ")
  print ("At this time, your total order price is $" + str(total) + ".")
  print (" ")
  kcp = "0"

if ketchput == "Yes":
 print ("One packet costs 25¢.")
 ketchcount = input ("Please input any number you'd like to specify how many ketchup packets you would like to order. If you change your mind, type 0.")
 print (" ")
 print ("You requested " + ketchcount + " ketchup packets.")
 kcp = str(ketchcount)

 ketchtotal = int(ketchcount) + float(ketchup)
 print ("That will be $" + str(ketchtotal) + ".")
 print (" ")
 total = int(ketchtotal) + float(total)
 print ("At this time, your total order price is $" + str(total) + ".")
 
if ketchput == "yes":
 print ("One packet costs 25¢.")
 ketchcount = input ("Please input any number you'd like to specify how many ketchup packets you would like to order. If you change your mind, type 0.")
 print (" ")
 print ("You requested " + ketchcount + " ketchup packets.")
 ketchtotal = int(ketchcount) + float(ketchup)
 print ("That will be $" + str(ketchtotal) + ".")
 print (" ")
 total = int(ketchtotal) + float(total)
 print ("At this time, your total order price is $" + str(total) + ".")

if ketchput == "YES":
 print ("One packet costs 25¢.")
 ketchcount = input ("Please input any number you'd like to specify how many ketchup packets you would like to order. If you change your mind, type 0.")
 print (" ")
 print ("You requested " + ketchcount + " ketchup packets.")
 ketchtotal = int(ketchcount) + float(ketchup)
 print ("That will be $" + str(ketchtotal) + ".")
 print (" ")
 total = int(ketchtotal) + float(total)
 print ("At this time, your total order price is $" + str(total) + ".")
 print (" ")

#Final Phase
print ("You have reached the end of the ordering phase.")
print ("We will now calculate the final price for your order:")
print (" ")

tally = int(tally) + int(0)  
if tally == 0:
 print("Here's your reciept:")
 print(" ")
 print(" ")
 print ("-𝐓𝐆𝟐𝟎𝟎𝟎'𝐬 𝐅𝐀𝐒𝐓 𝐒𝐇𝐀𝐂𝐊-")
 print(" ")
 print("Recipient: " + str(name))
 print("Sandwich: " + str(SWF))
 print("𝐂𝐨𝐤𝐞 Size: " + str(CK))
 print("Fry Size: " + str(fr))
 print("Number of Ketchup Packets: " + str(kcp))
 print("Price Deduction: No")
 print(" ")
 print("Your Final Order Price: $" + str(total))
 print(" ")
 print(" ")
 print (" ")
 print("Thank you for ordering at TG2000's Fast Shack! This is your reminder that this is a MOCK meal selection program, and that there is NO food delivery. If you were here to catch some grub, well too bad.")
 print (" ")
 print("If you're angry and you would like a refund, well good for you! You did not pay for anything!")
 print (" ")
 print("I hope you enjoyed this little simulation, this is the end of the program!")
 print (" ")
 print(" ")
 
if tally == 1:
 print("Here's your reciept:")
 print(" ")
 print(" ")
 print ("-𝐓𝐆𝟐𝟎𝟎𝟎'𝐬 𝐅𝐀𝐒𝐓 𝐒𝐇𝐀𝐂𝐊-")
 print(" ")
 print("Recipient: " + str(name))
 print("Sandwich: " + str(SWF))
 print("𝐂𝐨𝐤𝐞 Size: " + str(CK))
 print("Fry Size: " + str(fr))
 print("Number of Ketchup Packets: " + str(kcp))
 print("Price Deduction: No")
 print(" ")
 print("Your Final Order Price: $" + str(total))
 print(" ")
 print(" ")
 print (" ")
 print("Thank you for ordering at TG2000's Fast Shack! This is your reminder that this is a MOCK meal selection program, and that there is NO food delivery. If you were here to catch some grub, well too bad.")
 print (" ")
 print("If you're angry and you would like a refund, well good for you! You did not pay for anything!")
 print (" ")
 print("I hope you enjoyed this little simulation, this is the end of the program!")
 print (" ")
 print(" ")

if tally == 2:
 print("Here's your reciept:")
 print(" ")
 print(" ")
 print ("-𝐓𝐆𝟐𝟎𝟎𝟎'𝐬 𝐅𝐀𝐒𝐓 𝐒𝐇𝐀𝐂𝐊-")
 print(" ")
 print("Recipient: " + str(name))
 print("Sandwich: " + str(SWF))
 print("𝐂𝐨𝐤𝐞 Size: " + str(CK))
 print("Fry Size: " + str(fr))
 print("Number of Ketchup Packets: " + str(kcp))
 print("Price Deduction: No")
 print(" ")
 print("Your Final Order Price: $" + str(total))
 print(" ")
 print(" ")
 print (" ")
 print("Thank you for ordering at TG2000's Fast Shack! This is your reminder that this is a MOCK meal selection program, and that there is NO food delivery. If you were here to catch some grub, well too bad.")
 print (" ")
 print("If you're angry and you would like a refund, well good for you! You did not pay for anything!")
 print (" ")
 print("I hope you enjoyed this little simulation, this is the end of the program!")
 print (" ")
 print(" ")


if tally == 3:
  print("Here's your reciept:")
  print(" ")
  print(" ")
  print ("-𝐓𝐆𝟐𝟎𝟎𝟎'𝐬 𝐅𝐀𝐒𝐓 𝐒𝐇𝐀𝐂𝐊-")
  print(" ")
  print("Recipient: " + str(name))
  print("Sandwich: " + str(SWF))
  print("𝐂𝐨𝐤𝐞 Size: " + str(CK))
  print("Fry Size: " + str(fr))
  print("Number of Ketchup Packets: " + str(kcp))
  print("Price Deduction: Yes")
  print ("(Since you ordered a sandwich, a 𝐂𝐨𝐤𝐞, and fries, your price will be deducted by $1.00.)")
  finalprice = float(total) + float(-1)
  print(" ")
  print("Your Final Order Price: $" + str(finalprice))
  print(" ")
  print(" ")
  print("Thank you for ordering at TG2000's Fast Shack! This is your reminder that this is a MOCK meal selection program, and that there is NO food delivery. If you were here to catch some grub, well too bad.")
  print (" ")
  print("If you're angry and you would like a refund, well good for you! You did not pay for anything!")
  print (" ")
  print("I hope you enjoyed this little simulation, this is the end of the program!")
  print (" ")
  print(" ")
endsegment = input("If you would like to view the program info, type Pi. Else, hit Enter to quit the program.")
print (" ")
if endsegment == "Pi":
  print("TG2000's Fast Shack - Program Info")
  print("Programmed & Tested by TheGamer2000")
  print("Program Build #7.1, Build Date - 6/7/2024")
  print("Build Type - Final Public Distribution Build")
  print("Built on the Trinket Engine")
  print(" ")
  end = input("Press Enter Key To Quit.")
if endsegment == "PI":
  print("TG2000's Fast Shack - Program Info")
  print("Programmed & Tested by TheGamer2000")
  print("Program Build #7.1, Build Date - 6/7/2024")
  print("Build Type - Final Public Distribution Build")
  print("Built on the Trinket Engine")
  print(" ")
  end = input("Press Enter Key To Quit.")
  for rick in end:
   if end == ("Rick Astley"):
    print("NEVER GONNA GIVE YOU UP")
    print(" ")
    rickend = input ("You Got Rickrolled LOL")
if endsegment == "pi":
  print("TG2000's Fast Shack - Program Info")
  print("Programmed & Tested by TheGamer2000")
  print("Program Build #7.1, Build Date - 6/7/2024")
  print("Build Type - Final Public Distribution Build")
  print("Built on the Trinket Engine")
  print(" ")
  end = input("Press Enter Key To Quit.")
  if end == ("Tell me a duck story"):
   print("A duck walked up to a lemonade stand And he said to the man runnin' the stand Hey! [(bam bam bam)] Got any grapes? The man said: No, we just sell lemonade But it's cold, and it's fresh, and it's all home-made! Can I get you a glass? The duck said, I'll pass. Then he waddled away - waddle waddle Til the very next day Bom bom bom bom bom babom When the duck walked up to the lemonade stand And he said to the man runnin the stand Hey! (bam bam bam), got any grapes? The man said: No, like I said yesterday We just sell lemonade, okey? Why not give it a try? The duck said. Good bye Then he waddled away - waddle waddle Then he waddled away - waddle waddle Then he waddled away - waddle waddle Til the very next day When the duck walked up to the lemonade stand And he said to the man runnin' the stand Hey! (bam bam bam) Got any grapes? The man said: Look, this is gettin' old I mean, lemonade's all we've ever sold Why not give it a go? The duck said: How about - no. Then he waddled away - waddle waddle Then he waddled away - waddle waddle waddle Then he waddled away - waddle waddle Til the very next day When the duck walked up to the lemonade stand And he said to the man runnin' the stand: Hey! [(bam bam bam)] Got any grapes? The man said: That's it! If you don't stay away, duck I'll glue you to a tree and leave you there all day stuck! So don't get too close! The duck said, Adios Then he waddled away - waddle waddle Then he waddled away - waddle waddle waddle Then he waddled away - waddle waddle Til the very next day When the duck walked up to the lemonade stand And he said to the man runnin' the stand Hey! [(bam bam bam)] Got any glue? What? Got any glue? No, why would I - oh... Then one more question for you: Got any grapes? And the man just stopped The he started to smile He started to laugh He laughed for a while. He said: Come on, duck Let's walk to the store I'll buy you some grapes So you don't have to ask anymore So they walked to the store And the man bought some grapes He gave one to the duck And the duck said: Hmm, no thanks But you know what sounds good? It would make my day Do you think this store Do you think this store Do you think this store Has any lemonade? Then he waddled away - waddle waddle Then he waddled away - waddle waddle waddle Then he waddled away - waddle waddle")
   print(" ")
   duckend = input("OK, the Duck got his grapes. Please press ENTER to quit.")